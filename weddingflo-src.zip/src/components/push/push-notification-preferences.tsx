/**
 * Push Notification Preferences Component
 *
 * Provides granular control over notification types:
 * - Task reminders
 * - Event reminders
 * - Client updates
 * - System alerts
 *
 * Changes are saved immediately to the database
 */

'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { trpc } from '@/lib/trpc/client';
import { toast } from 'sonner';
import { Loader2, Users, Calendar, CheckSquare, Info, Bell } from 'lucide-react';

interface PreferenceItemProps {
  icon: React.ReactNode;
  label: string;
  description: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
}

function PreferenceItem({
  icon,
  label,
  description,
  checked,
  onCheckedChange,
  disabled = false,
}: PreferenceItemProps) {
  return (
    <div className="flex items-center justify-between space-x-4 py-4">
      <div className="flex items-start space-x-4 flex-1">
        <div className="mt-1 text-muted-foreground">{icon}</div>
        <div className="space-y-1 flex-1">
          <Label
            htmlFor={label.toLowerCase().replace(/\s+/g, '-')}
            className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
          </Label>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch
        id={label.toLowerCase().replace(/\s+/g, '-')}
        checked={checked}
        onCheckedChange={onCheckedChange}
        disabled={disabled}
      />
    </div>
  );
}

export function PushNotificationPreferences() {
  const utils = trpc.useUtils();

  // Get current preferences
  const {
    data: preferences,
    isLoading,
  } = trpc.push.getPreferences.useQuery();

  // Update preferences mutation with optimistic updates
  const updateMutation = trpc.push.updatePreferences.useMutation({
    onMutate: async (newData) => {
      // Cancel outgoing refetches
      await utils.push.getPreferences.cancel();

      // Snapshot previous value
      const previousPreferences = utils.push.getPreferences.getData();

      // Optimistically update the cache
      utils.push.getPreferences.setData(undefined, (old: typeof previousPreferences) => {
        if (!old) return old;
        return { ...old, ...newData };
      });

      return { previousPreferences };
    },
    onError: (error, _newData, context) => {
      // Rollback on error
      if (context?.previousPreferences) {
        utils.push.getPreferences.setData(undefined, context.previousPreferences);
      }
      toast.error('Failed to update preferences', {
        description: error.message,
      });
    },
    onSettled: () => {
      // Refetch in background to ensure consistency
      utils.push.getPreferences.invalidate();
    },
  });

  const handleUpdatePreference = (field: string, value: boolean) => {
    updateMutation.mutate({ [field]: value } as any);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (!preferences) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription>
            No preferences found. Please enable push notifications first.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notification Preferences
        </CardTitle>
        <CardDescription>
          Choose which types of notifications you want to receive
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-0">
        {/* Global Enable/Disable */}
        <div className="rounded-lg bg-muted/50 p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="push-enabled" className="text-base font-semibold">
                Master Switch
              </Label>
              <p className="text-sm text-muted-foreground mt-1">
                Turn all push notifications on or off
              </p>
            </div>
            <Switch
              id="push-enabled"
              checked={preferences.enabled ?? true}
              onCheckedChange={(checked) =>
                handleUpdatePreference('enabled', checked)
              }
              disabled={updateMutation.isPending}
            />
          </div>
        </div>

        <Separator className="my-4" />

        {/* Individual Preferences */}
        <div className="space-y-1">
          <PreferenceItem
            icon={<CheckSquare className="h-5 w-5" />}
            label="Reminders"
            description="Task reminders, event reminders, and schedule updates"
            checked={preferences.reminders ?? true}
            onCheckedChange={(checked) =>
              handleUpdatePreference('reminders', checked)
            }
            disabled={!preferences.enabled || updateMutation.isPending}
          />

          <Separator />

          <PreferenceItem
            icon={<Users className="h-5 w-5" />}
            label="RSVP Updates"
            description="Guest confirmations, cancellations, and RSVP activity"
            checked={preferences.rsvpUpdates ?? true}
            onCheckedChange={(checked) =>
              handleUpdatePreference('rsvpUpdates', checked)
            }
            disabled={!preferences.enabled || updateMutation.isPending}
          />

          <Separator />

          <PreferenceItem
            icon={<Info className="h-5 w-5" />}
            label="Messages"
            description="Direct messages and system notifications"
            checked={preferences.messages ?? true}
            onCheckedChange={(checked) =>
              handleUpdatePreference('messages', checked)
            }
            disabled={!preferences.enabled || updateMutation.isPending}
          />
        </div>

        {/* Help Text */}
        <div className="mt-6 text-xs text-muted-foreground">
          <p>
            Changes are saved automatically. Critical security notifications cannot be
            disabled.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
